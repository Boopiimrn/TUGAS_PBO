/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package muhammadrofinugraha_2110010241;

/**
 *
 * @author ACER
 */
import java.util.Scanner;
public class MuhammadRofiNugraha_2110010241 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String nama, npm;
        
        Scanner input = new Scanner(System.in);
        System.out.print("Input Nama Lengkap Anda : ");
        nama = input.nextLine();
        System.out.print("Input NPM Anda : ");
        npm = input.nextLine();
        
        System.out.println("Nama : " + nama);
        System.out.println("NPM : " + npm);
    }
    
}
